// Disable datalabels globally, enable only for specific charts
        Chart.defaults.plugins.datalabels = { display: false };

        // Theme colors
        const colors = {
            text: '#5a6577',
            grid: 'rgba(26, 43, 95, 0.1)',
            legend: '#1a2b5f',
            accentBlue: '#5BA4E6',
            primaryNavy: '#1a2b5f',
            successGreen: '#2d8a5f',
            warning: '#c9a227',
            danger: '#E53935'
        };

        // ==================== TAB FUNCTIONALITY ====================
        const tabBtns = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const tabId = btn.dataset.tab;

                tabBtns.forEach(b => b.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));

                btn.classList.add('active');
                document.getElementById(tabId).classList.add('active');
            });
        });

        // ==================== APR METRICS DATA (from apr-chart.html) ====================
        const aprData = {
            labels: ["2024-10-22", "2024-10-23", "2024-10-24", "2024-10-25", "2024-10-26", "2024-10-27", "2024-10-28", "2024-10-29", "2024-10-30", "2024-10-31", "2024-11-01", "2024-11-02", "2024-11-03", "2024-11-04", "2024-11-05", "2024-11-06", "2024-11-07", "2024-11-08", "2024-11-09", "2024-11-10", "2024-11-11", "2024-11-12", "2024-11-13", "2024-11-14", "2024-11-15", "2024-11-16", "2024-11-17", "2024-11-18", "2024-11-19", "2024-11-20", "2024-11-21", "2024-11-22", "2024-11-23", "2024-11-24", "2024-11-25", "2024-11-26", "2024-11-27", "2024-11-28", "2024-11-29", "2024-11-30", "2024-12-01", "2024-12-02", "2024-12-03", "2024-12-04", "2024-12-05", "2024-12-06", "2024-12-07", "2024-12-08", "2024-12-09", "2024-12-10", "2024-12-11", "2024-12-12", "2024-12-13", "2024-12-14", "2024-12-15", "2024-12-16", "2024-12-17", "2024-12-18", "2024-12-19", "2024-12-20", "2024-12-21", "2024-12-22", "2024-12-23", "2024-12-24", "2024-12-25", "2024-12-26", "2024-12-27", "2024-12-28", "2024-12-29", "2024-12-30", "2024-12-31", "2025-01-01", "2025-01-02", "2025-01-03", "2025-01-04", "2025-01-05", "2025-01-06", "2025-01-07", "2025-01-08", "2025-01-09", "2025-01-10", "2025-01-11", "2025-01-12", "2025-01-13", "2025-01-14", "2025-01-15", "2025-01-16", "2025-01-17", "2025-01-18", "2025-01-19", "2025-01-20", "2025-01-21", "2025-01-22", "2025-01-23", "2025-01-24", "2025-01-25", "2025-01-26", "2025-01-27", "2025-01-28", "2025-01-29", "2025-01-30", "2025-01-31", "2025-02-01", "2025-02-02", "2025-02-03", "2025-02-04", "2025-02-05", "2025-02-06", "2025-02-07", "2025-02-08", "2025-02-09", "2025-02-10", "2025-02-11", "2025-02-12", "2025-02-13", "2025-02-14", "2025-02-15", "2025-02-16", "2025-02-17", "2025-02-18", "2025-02-19", "2025-02-20", "2025-02-21", "2025-02-22", "2025-02-23", "2025-02-24", "2025-02-25", "2025-02-26", "2025-02-27", "2025-02-28", "2025-03-01", "2025-03-02", "2025-03-03", "2025-03-04", "2025-03-05", "2025-03-06", "2025-03-07", "2025-03-08", "2025-03-09", "2025-03-10", "2025-03-11", "2025-03-12", "2025-03-13", "2025-03-14", "2025-03-15", "2025-03-16", "2025-03-17", "2025-03-18", "2025-03-19", "2025-03-20", "2025-03-21", "2025-03-22", "2025-03-23", "2025-03-24", "2025-03-25", "2025-03-26", "2025-03-27", "2025-03-28", "2025-03-29", "2025-03-30", "2025-03-31", "2025-04-01", "2025-04-02", "2025-04-03", "2025-04-04", "2025-04-05", "2025-04-06", "2025-04-07", "2025-04-08", "2025-04-09", "2025-04-10", "2025-04-11", "2025-04-12", "2025-04-13", "2025-04-14", "2025-04-15", "2025-04-16", "2025-04-17", "2025-04-18", "2025-04-19", "2025-04-20", "2025-04-21", "2025-04-22", "2025-04-23", "2025-04-24", "2025-04-25", "2025-04-26", "2025-04-27", "2025-04-28", "2025-04-29", "2025-04-30", "2025-05-01", "2025-05-02", "2025-05-03", "2025-05-04", "2025-05-05", "2025-05-06", "2025-05-07", "2025-05-08", "2025-05-09", "2025-05-10", "2025-05-11", "2025-05-12", "2025-05-13", "2025-05-14", "2025-05-15", "2025-05-16", "2025-05-17", "2025-05-18", "2025-05-19", "2025-05-20", "2025-05-21", "2025-05-22", "2025-05-23", "2025-05-24", "2025-05-25", "2025-05-26", "2025-05-27", "2025-05-28", "2025-05-29", "2025-05-30", "2025-05-31", "2025-06-01", "2025-06-02", "2025-06-03", "2025-06-04", "2025-06-05", "2025-06-06", "2025-06-07", "2025-06-08", "2025-06-09", "2025-06-10", "2025-06-11", "2025-06-12", "2025-06-13", "2025-06-14", "2025-06-15", "2025-06-16", "2025-06-17", "2025-06-18", "2025-06-19", "2025-06-20", "2025-06-21", "2025-06-22", "2025-06-23", "2025-06-24", "2025-06-25", "2025-06-26", "2025-06-27", "2025-06-28", "2025-06-29", "2025-06-30", "2025-07-01", "2025-07-02", "2025-07-03", "2025-07-04", "2025-07-05", "2025-07-06", "2025-07-07", "2025-07-08", "2025-07-09", "2025-07-10", "2025-07-11", "2025-07-12", "2025-07-13", "2025-07-14", "2025-07-15", "2025-07-16", "2025-07-17", "2025-07-18", "2025-07-19", "2025-07-20", "2025-07-21", "2025-07-22", "2025-07-23", "2025-07-24", "2025-07-25", "2025-07-26", "2025-07-27", "2025-07-28", "2025-07-29", "2025-07-30", "2025-07-31", "2025-08-01", "2025-08-02", "2025-08-03", "2025-08-04", "2025-08-05", "2025-08-06", "2025-08-07", "2025-08-08", "2025-08-09", "2025-08-10", "2025-08-11", "2025-08-12", "2025-08-13", "2025-08-14", "2025-08-15", "2025-08-16", "2025-08-17", "2025-08-18", "2025-08-19", "2025-08-20", "2025-08-21", "2025-08-22", "2025-08-23", "2025-08-24", "2025-08-25", "2025-08-26", "2025-08-27", "2025-08-28", "2025-08-29", "2025-08-30", "2025-08-31", "2025-09-01", "2025-09-02", "2025-09-03", "2025-09-04", "2025-09-05", "2025-09-06", "2025-09-07", "2025-09-08", "2025-09-09", "2025-09-10", "2025-09-11", "2025-09-12", "2025-09-13", "2025-09-14", "2025-09-15", "2025-09-16", "2025-09-17", "2025-09-18", "2025-09-19", "2025-09-20", "2025-09-21", "2025-09-22", "2025-09-23", "2025-09-24", "2025-09-25", "2025-09-26", "2025-09-27", "2025-09-28", "2025-09-29", "2025-09-30", "2025-10-01", "2025-10-02", "2025-10-03", "2025-10-04", "2025-10-05", "2025-10-06", "2025-10-07", "2025-10-08", "2025-10-09", "2025-10-10", "2025-10-11", "2025-10-12", "2025-10-13", "2025-10-14", "2025-10-15", "2025-10-16", "2025-10-17", "2025-10-18", "2025-10-19", "2025-10-20", "2025-10-21", "2025-10-22", "2025-10-23", "2025-11-04", "2025-11-05", "2025-11-06", "2025-11-07", "2025-11-10", "2025-11-11", "2025-11-12", "2025-11-13", "2025-11-14", "2025-11-15", "2025-11-16", "2025-11-17", "2025-11-18", "2025-11-19", "2025-11-20", "2025-11-21", "2025-11-22", "2025-12-04", "2025-12-05", "2025-12-06", "2025-12-07", "2025-12-10", "2025-12-11", "2025-12-12", "2025-12-13"],
            expected_apr: [9.5, 9.79, 9.9, 9.9, 10.34, 10.13, 9.88, 10.28, 11.07, 11.62, 11.17, 10.78, 10.65, 10.21, 10.24, 10.56, 11.08, 10.83, 10.91, 11.76, 16.33, 22.57, 20.19, 21.0, 24.13, 16.94, 25.45, 26.02, 21.94, 17.62, 16.78, 22.21, 20.26, 21.56, 22.59, 32.09, 27.24, 20.51, 19.87, 22.23, 25.01, 32.64, 35.64, 33.77, 37.69, 38.29, 34.28, 41.68, 38.9, 24.15, 20.89, 16.96, 17.23, 15.6, 16.42, 19.48, 16.31, 16.31, 14.07, 8.6, 7.86, 8.79, 8.99, 9.57, 8.64, 8.59, 9.26, 15.73, 11.47, 13.5, 10.16, 10.84, 9.76, 8.49, 8.85, 8.15, 8.92, 6.97, 8.36, 8.15, 7.79, 8.52, 8.63, 8.79, 8.61, 8.52, 8.11, 7.44, 8.74, 8.74, 8.56, 8.86, 7.43, 9.29, 8.28, 9.08, 9.07, 8.74, 8.66, 8.82, 8.7, 8.88, 10.02, 9.43, -0.04, -8.56, 0.65, -4.27, -0.03, -0.93, -10.87, -4.83, -6.28, -2.34, -3.32, -2.21, -1.36, 3.35, -4.24, -2.02, -5.32, -3.74, -1.92, 2.15, -0.4, -1.52, -7.17, -0.56, 2.95, 5.64, 5.47, 4.37, -0.41, 4.26, -3.4, -8.93, -2.22, 1.27, 1.95, 3.68, -2.54, -0.53, -1.45, 2.35, 0.26, -2.78, -0.94, -1.09, 1.59, -0.64, 3.09, 0.62, 0.09, -3.09, -7.34, -5.42, -4.22, -1.03, -1.88, -5.37, -3.26, 0.48, 3.06, 5.48, null, 5.73, 8.37, 3.05, -1.98, 1.11, 0.25, 3.01, 6.28, 2.34, 5.64, 1.95, 2.17, 3.34, -1.48, 0.04, -1.06, -0.07, -1.2, 5.2, 4.92, 5.4, 3.83, 7.93, 5.6, 5.38, 6.18, 6.88, 7.15, 6.24, 6.62, 7.44, 8.83, 9.09, 8.04, 10.26, 11.24, 10.19, 11.59, 12.25, 13.11, 9.4, 10.82, 9.22, 8.21, 7.29, 6.36, 9.39, 11.42, 12.3, 11.03, 10.49, 8.88, 8.0, 7.56, 7.92, 5.71, 6.21, 4.14, 4.68, 6.49, 7.19, 9.43, 4.5, 6.45, 5.34, 7.58, 10.68, 11.44, 12.32, 11.14, 12.09, 9.88, 12.41, 9.27, 10.31, 11.87, 11.39, 5.3, 5.65, 5.12, 4.19, 8.26, 7.8, 5.23, 5.8, 7.85, 10.51, 9.59, 6.78, 7.21, 9.43, 5.97, 5.18, 7.77, 7.66, 5.38, 9.78, 10.51, 12.1, 13.37, 13.9, 14.1, 12.96, 14.19, 14.64, 15.07, 15.98, 18.32, 17.22, 17.46, 15.19, 15.38, 15.15, 14.86, 14.76, 14.17, 14.35, 11.71, 12.04, 9.0, 7.28, 7.39, 8.46, 11.21, 11.7, 10.82, 12.4, 12.39, 13.49, 13.69, 15.15, 15.53, 15.55, 9.94, 10.42, 10.48, 9.63, 9.63, 12.87, 12.75, 13.64, 13.5, 14.2, 8.47, 13.4, 13.02, 13.73, 12.83, 12.27, 12.16, 11.82, 12.37, 10.5, 12.16, 12.58, 12.66, 13.25, 12.5, 13.47, 13.45, 13.57, 13.31, 13.99, 14.59, 14.76, 13.12, 13.84, 13.13, 9.68, 13.06, 11.3, 9.33, 12.54, 6.33, 7.55, 6.5, 9.33, 10.72, 10.97, 11.85, 10.42, 8.3, 12.39, 11.03, 11.41, 10.02, 7.34, 10.38, 8.16, 7.85, 7.85, 7.85, -4.51, -2.54, -0.46, -0.26, 1.02, 1.53, 1.58, 1.77, 1.74, 0.52, 2.21, 3.57, 1.4, 6.61, 4.97, 5.0, 4.32, 5.12, null, null, 5.71, 8.4, 7.8, 8.06, 6.9, 8.05, 1.64, 4.93, 4.36, 2.03, 4.38, 4.08, 1.18, 4.21, 2.43],
            implied_apr: [9.5, 9.79, 9.9, 9.9, 10.34, 10.13, 9.88, 10.28, 11.07, 11.62, 11.17, 10.78, 10.65, 10.21, 10.24, 10.56, 11.08, 10.83, 10.91, 11.76, 16.33, 22.57, 20.19, 21.0, 24.13, 16.94, 25.45, 26.02, 21.94, 17.62, 16.78, 22.21, 20.26, 21.56, 22.59, 32.09, 27.24, 20.51, 19.87, 22.23, 25.01, 32.64, 35.64, 33.77, 37.69, 38.29, 34.28, 41.68, 38.9, 24.15, 20.89, 16.96, 17.23, 15.6, 16.42, 19.48, 16.31, 16.31, 14.07, 8.6, 7.86, 8.79, 8.99, 9.57, 8.64, 8.59, 9.26, 15.73, 11.47, 13.5, 10.16, 10.84, 9.76, 8.49, 8.85, 8.15, 8.92, 6.97, 8.36, 8.15, 7.79, 8.52, 8.63, 8.79, 8.61, 8.52, 8.11, 7.44, 8.74, 8.74, 8.56, 8.86, 7.43, 9.29, 8.28, 9.08, 9.07, 8.74, 8.66, 8.82, 8.7, 8.88, 10.02, 9.43, -0.04, -8.56, 0.65, -4.27, -0.03, -0.93, -10.87, -4.83, -6.28, -2.34, -3.32, -2.21, -1.36, 3.35, -4.24, -2.02, -5.32, -3.74, -1.92, 2.15, -0.4, -1.52, -7.17, -0.56, 2.95, 5.64, 5.47, 4.37, -0.41, 4.26, -3.4, -8.93, -2.22, 1.27, 1.95, 3.68, -2.54, -0.53, -1.45, 2.35, 0.26, -2.78, -0.94, -1.09, 1.59, -0.64, 3.09, 0.62, 0.09, -3.09, -7.34, -5.42, -4.22, -1.03, -1.88, -5.37, -3.26, 0.48, 2.34, 1.9, null, 2.88, 4.93, 0.48, -4.41, -1.43, -2.33, 0.13, 3.26, -1.09, 2.21, -1.32, -1.11, 0.01, -4.8, -3.62, -4.79, -3.71, -4.91, 1.42, 1.14, 1.94, 0.45, 3.27, 0.93, 1.37, 2.16, 3.05, 3.34, 2.34, 2.72, 3.45, 4.86, 5.38, 4.28, 6.4, 7.37, 6.27, 7.47, 8.01, 8.9, 5.44, 6.87, 4.55, 3.49, 2.8, 1.98, 5.28, 7.3, 8.21, 7.02, 6.48, 4.88, 4.04, 3.63, 4.15, 2.03, 2.38, 0.38, 1.07, 2.87, 3.57, 5.83, 0.61, 2.57, 1.62, 3.86, 6.66, 7.38, 8.48, 7.32, 8.2, 5.99, 8.52, 5.38, 6.61, 8.13, 7.67, 1.5, 2.73, 2.26, 0.95, 4.11, 3.48, 0.76, 1.54, 3.6, 6.03, 5.11, 2.32, 2.87, 5.24, 1.71, 0.76, 3.2, 3.23, 1.36, 5.63, 6.31, 7.66, 8.86, 9.36, 9.56, 8.91, 9.7, 10.34, 10.28, 11.0, 13.07, 11.87, 12.06, 10.72, 11.03, 10.69, 10.41, 10.39, 9.97, 10.15, 7.51, 7.76, 4.73, 3.01, 3.09, 4.15, 7.02, 7.48, 6.46, 8.05, 8.09, 9.18, 9.35, 10.44, 10.7, 10.71, 5.13, 5.91, 6.02, 5.12, 5.12, 8.62, 8.51, 9.41, 9.35, 9.85, 4.24, 9.18, 8.93, 9.64, 8.88, 8.4, 8.12, 7.77, 8.46, 6.6, 8.36, 8.77, 8.84, 9.43, 8.78, 9.75, 9.79, 9.91, 9.53, 10.13, 10.45, 10.62, 9.15, 9.85, 9.0, 5.55, 9.15, 7.47, 5.6, 8.81, 2.59, 3.82, 2.78, 5.61, 7.0, 7.24, 8.1, 6.66, 4.51, 8.6, 7.28, 7.67, 6.31, 3.62, 6.72, 4.49, 4.16, 4.16, 4.16, -6.02, -3.86, -1.48, -1.22, 0.06, 0.55, 0.6, 0.8, 0.77, -0.13, -0.34, 1.02, -1.14, 3.85, 2.34, 2.21, 1.51, 2.31, null, null, 3.0, 5.61, 5.02, 5.27, 4.09, 5.23, -1.24, 1.8, 1.23, -1.06, 1.24, 0.99, -1.89, 1.15, -0.72],
            ninety_day_apy: [81.52, 81.77, 80.96, 80.74, 79.26, 79.36, 80.89, 83.46, 84.88, 85.31, 85.58, 86.38, 69.9, 51.36, 45.38, 47.62, 48.72, 43.17, 34.39, 34.07, 34.5, 35.47, 35.47, 47.01, 48.94, 49.82, 50.38, 50.21, 45.85, 45.91, 45.91, 46.47, 49.49, 50.18, 52.14, 52.3, 52.78, 53.7, 53.41, 55.37, 54.23, 54.43, 49.56, 54.08, 57.75, 53.53, 56.05, 47.99, 46.09, 45.7, 44.2, 43.15, 44.17, 45.97, 51.84, 46.79, 49.05, 37.5, 33.39, 30.4, 35.67, 34.14, 25.51, 33.94, 27.32, 19.96, 21.12, 19.08, 24.87, 27.87, 27.04, 33.01, 35.89, 31.9, 35.23, 34.62, 38.26, 61.87, 25.69, 21.79, 21.9, 25.89, 20.89, 18.57, 19.09, 24.99, 28.05, -23.23, 30.77, 30.77, 34.01, 34.87, 34.05, 32.57, 35.27, 31.11, 30.72, 21.53, 22.38, 24.17, -47.82, 26.85, 25.79, 26.24, 24.44, 17.26, 17.58, 31.62, 31.56, 29.95, 28.96, 27.73, 3.45, 14.2, 13.85, 16.62, 13.47, 12.88, 14.24, 14.85, 14.7, 13.91, 11.85, 12.59, 11.98, 12.71, 11.6, 13.07, 11.35, 11.0, 12.44, 15.43, 10.87, 11.69, 9.66, 8.24, -183.33, 9.36, 10.14, 12.96, 12.27, 11.35, 11.85, 12.88, 13.97, 14.12, 13.57, 13.05, 15.57, 18.23, 19.59, 18.85, 21.44, 15.58, 19.49, 23.08, 20.62, 19.37, 19.72, 17.41, 18.76, 18.21, 12.64, 10.91, 11.11, 12.76, 7.57, 9.32, 20.75, 26.92, 24.41, 25.89, 30.11, 40.27, 35.8, 28.03, 26.33, 24.84, 24.29, 25.14, 19.95, 18.74, 19.76, -34.08, 12.45, 26.04, 27.03, 35.18, 34.34, 33.54, 29.12, 32.8, 31.14, 30.73, 31.75, 38.63, 33.33, 31.75, 32.51, 32.79, 31.77, 33.82, 35.11, 34.33, 37.48, 31.58, 29.78, 28.01, 24.93, 25.66, 31.22, 31.93, 28.94, 25.07, 32.26, 33.91, 30.41, 30.59, 31.24, 29.71, 32.06, 33.49, 33.92, 33.65, 34.03, 29.86, 33.15, 36.4, 35.94, 35.71, 34.55, 31.13, 26.05, 27.8, 30.29, 31.55, 32.53, 31.12, 28.67, 32.65, 29.87, 32.39, 29.21, 24.86, 25.34, 24.6, 27.61, 27.87, 27.21, 29.14, 28.89, 28.59, 24.54, 30.52, 25.2, 25.05, 27.31, 27.67, 28.51, 19.67, 24.86, 15.52, 10.47, 11.16, 11.69, 11.19, 13.18, 7.69, 6.96, 3.53, 4.56, 9.68, 3.44, 2.1, -0.81, 0.95, 1.04, 0.91, 1.43, 1.43, 0.95, 1.22, 2.74, 1.32, 0.66, -7.04, 0.59, 0.44, -0.78, -0.66, 0.42, 0.91, -0.73, 1.37, -4.26, 5.21, 5.66, 9.65, 10.74, 7.92, 1.37, 2.93, 6.28, 3.47, 0.37, 1.77, 2.76, 3.63, 1.83, 1.04, -0.68, -1.01, -1.65, -3.74, -3.28, 2.9, -7.32, -7.04, -6.99, -6.59, -6.0, -1.65, 3.05, -3.62, -4.17, -5.23, -4.21, -3.48, -1.12, -6.88, -4.84, -9.93, -6.21, 5.86, 5.52, 7.03, 7.87, 7.65, 6.41, 7.6, 7.05, 7.82, 6.76, 7.66, 8.36, 8.7, 7.83, 8.5, 7.58, 7.86, 14.77, 9.35, 9.34, 8.29, 7.81, 7.86, 7.61, 10.86, 11.31, 15.56, 12.79, 6.69, 13.28, 14.21, 13.24, 13.69, 14.17, 16.03, 15.53, 14.39, 14.26, 7.74, 10.68, 10.03, 10.14, 11.94, 11.23, 11.37, 10.89, 11.46, 10.78, 11.22, 9.42, 9.32, 16.06, 14.83, 13.81, 13.83, 15.17, 13.69, 15.74, 16.03],
            thirty_day_apy: [51.99, 48.65, 29.12, 40.25, 14.77, 10.02, 13.34, 15.75, 26.93, 35.65, 31.79, 48.48, 33.47, 29.55, 27.73, 46.93, 50.18, 37.42, 5.66, 3.42, 3.02, 13.67, -1.84, 37.47, 42.26, 51.08, 45.99, 43.66, 36.71, 32.24, 31.94, 36.47, 36.91, 36.05, 42.99, 39.91, 39.47, 36.55, 35.79, 43.91, 46.1, 48.35, 55.62, 57.73, 56.83, 41.87, 43.55, 86.59, 85.48, 71.14, 69.27, 71.63, 68.25, 31.1, 28.37, 26.94, 25.68, 21.79, 22.35, 16.6, 19.23, 15.22, 7.43, 22.33, 21.46, 9.12, 6.32, 3.55, 7.04, 2.06, 1.67, -0.68, 17.69, 6.26, 13.83, 11.0, 16.69, 79.28, -12.46, -11.01, -11.51, -8.25, -5.5, -14.23, -14.57, -4.89, 10.18, -128.9, 24.61, 24.61, 51.75, 47.75, 55.87, 30.44, 41.64, 43.16, 44.24, 19.93, 26.25, 20.13, -182.56, 27.58, 0.49, -0.19, -0.19, -1.6, -12.63, 8.76, 23.4, 30.38, 15.59, 19.04, -50.48, 36.25, 23.58, 12.63, 4.87, -7.58, -12.68, -17.68, -22.02, -25.63, -24.69, -22.95, -22.65, -15.96, -13.04, 14.0, 11.01, 8.93, 2.49, 23.3, 12.43, 14.13, 15.97, 15.92, -554.74, 21.12, 20.69, 20.35, 24.5, 23.65, 24.54, 24.85, 30.74, 30.01, 27.18, 22.08, 25.45, 29.03, 30.72, 32.16, 33.75, 38.58, 40.21, 39.42, 27.5, 26.97, 26.98, 18.65, 17.71, 19.19, 23.84, 17.08, 18.13, 23.24, 13.58, -2.04, 16.79, 27.36, 32.33, 34.05, 49.12, 51.62, 50.11, 51.28, 49.33, 57.09, 53.36, 52.93, 52.55, 50.4, 49.01, -117.38, 20.76, 54.28, 63.58, 64.02, 62.66, 65.15, 64.01, 63.12, 44.37, 62.92, 54.24, 75.28, 65.39, 62.04, 64.94, 38.77, 47.49, 32.57, 22.19, 21.6, 29.8, 12.39, 12.53, 2.29, -5.81, -6.22, 9.43, 11.63, -2.88, -14.54, 1.11, 5.24, 0.29, -1.42, 2.64, 4.68, 10.91, 16.69, 21.19, 22.53, 22.02, -11.8, 26.4, 34.5, 29.76, 28.32, 27.03, 16.09, -3.59, 12.14, 4.95, 30.89, 32.06, 36.8, 41.58, 48.47, 22.25, 35.61, 39.25, 42.49, 12.11, 13.64, 16.99, 20.14, 13.36, 14.15, 8.31, 6.15, 7.31, 2.22, -0.89, 15.84, -13.04, -12.59, -11.09, -9.09, -5.06, 2.41, 15.0, -3.98, -5.19, -7.67, -3.77, -11.44, -9.19, -33.43, -21.92, -18.13, -20.76, -4.11, -24.03, -15.74, -15.4, -15.06, -19.25, -15.08, -18.5, -16.78, -20.75, -20.59, -17.79, -17.74, -19.38, -18.0, -22.05, -20.07, 4.22, -9.49, -9.19, -10.04, -12.32, -8.31, -9.09, 3.87, 1.99, 11.58, 1.24, -15.89, 4.09, -11.03, 7.57, 7.46, 6.45, 5.24, 4.99, 5.71, 9.3, 9.48, 8.29, 9.13, 9.37, 10.9, 10.05, 11.13, 10.39, 9.57, 6.26, 3.93, 3.17, 2.89, 2.28, 0.89, -0.1, -0.5, 6.37, 5.53, 2.81, -1.55, -0.06, 14.31, 28.01, 29.93, 33.26, 31.6, 33.24, 32.44, 32.09, 30.64, 35.0, 36.16, 33.29, 33.75, 32.99, 33.6, 34.47, 34.82, 33.05, 33.55, 34.17, 32.23, 31.64, 31.95, 31.85, 30.56, 26.3, 28.38, 36.18, 37.4, 34.14, 4.23, 2.38, 2.17, 2.47, 2.85, 1.61, 4.37, 4.72, -10.72, -0.64, -1.44, 1.36, 0.09, -0.69, -2.53, -3.75, -0.32, -0.85, 4.31, -4.78, -7.94, 10.21, 7.43, 4.52, 2.69, 13.38, 10.53, 15.95, 15.85]
        };

        // Series visibility state
        const seriesVisible = {
            expected: true,
            implied: true,
            ninety: true,
            thirty: true
        };

        // APR Chart
        const aprCtx = document.getElementById('aprChart').getContext('2d');
        const aprChart = new Chart(aprCtx, {
            type: 'line',
            data: {
                labels: aprData.labels,
                datasets: [
                    {
                        label: 'Expected APR',
                        data: aprData.expected_apr,
                        borderColor: '#5BA4E6',
                        backgroundColor: 'rgba(91, 164, 230, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 0,
                        borderWidth: 2
                    },
                    {
                        label: 'Implied APR',
                        data: aprData.implied_apr,
                        borderColor: '#1a2b5f',
                        backgroundColor: 'transparent',
                        fill: false,
                        tension: 0.4,
                        pointRadius: 0,
                        borderWidth: 2
                    },
                    {
                        label: '90-Day APY',
                        data: aprData.ninety_day_apy,
                        borderColor: '#2D8A5F',
                        backgroundColor: 'transparent',
                        fill: false,
                        tension: 0.4,
                        pointRadius: 0,
                        borderWidth: 2
                    },
                    {
                        label: '30-Day APY',
                        data: aprData.thirty_day_apy,
                        borderColor: '#c9a227',
                        backgroundColor: 'transparent',
                        fill: false,
                        tension: 0.4,
                        pointRadius: 0,
                        borderWidth: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(26, 43, 95, 0.95)',
                        titleFont: { family: "'Source Serif 4', Georgia, serif" },
                        bodyFont: { family: "'Source Serif 4', Georgia, serif" },
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + (context.parsed.y !== null ? context.parsed.y.toFixed(2) + '%' : 'N/A');
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { color: 'rgba(26, 43, 95, 0.1)' },
                        ticks: {
                            color: '#5a6577',
                            maxTicksLimit: 12,
                            font: { family: "'Source Serif 4', Georgia, serif" }
                        }
                    },
                    y: {
                        grid: { color: 'rgba(26, 43, 95, 0.1)' },
                        ticks: {
                            color: '#5a6577',
                            callback: value => value + '%',
                            font: { family: "'Source Serif 4', Georgia, serif" }
                        }
                    }
                }
            }
        });

        // Update APR stats
        function updateAPRStats() {
            const lastIdx = aprData.expected_apr.length - 1;
            const expected = aprData.expected_apr[lastIdx];
            const implied = aprData.implied_apr[lastIdx];
            const ninety = aprData.ninety_day_apy[lastIdx];
            const thirty = aprData.thirty_day_apy[lastIdx];

            document.getElementById('apr-expected').textContent = expected ? expected.toFixed(2) + '%' : 'N/A';
            document.getElementById('apr-expected').className = 'stat-value ' + (expected >= 0 ? 'positive' : 'negative');

            document.getElementById('apr-implied').textContent = implied ? implied.toFixed(2) + '%' : 'N/A';
            document.getElementById('apr-implied').className = 'stat-value ' + (implied >= 0 ? 'positive' : 'negative');

            document.getElementById('apr-90day').textContent = ninety ? ninety.toFixed(2) + '%' : 'N/A';
            document.getElementById('apr-90day').className = 'stat-value ' + (ninety >= 0 ? 'positive' : 'negative');

            document.getElementById('apr-30day').textContent = thirty ? thirty.toFixed(2) + '%' : 'N/A';
            document.getElementById('apr-30day').className = 'stat-value ' + (thirty >= 0 ? 'positive' : 'negative');
        }
        updateAPRStats();

        // APR Time filter buttons
        document.querySelectorAll('#apr-metrics .chart-filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('#apr-metrics .chart-filter-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');

                const range = this.dataset.range;
                let startIdx = 0;

                if (range !== 'all') {
                    const days = parseInt(range);
                    startIdx = Math.max(0, aprData.labels.length - days);
                }

                aprChart.data.labels = aprData.labels.slice(startIdx);
                aprChart.data.datasets[0].data = aprData.expected_apr.slice(startIdx);
                aprChart.data.datasets[1].data = aprData.implied_apr.slice(startIdx);
                aprChart.data.datasets[2].data = aprData.ninety_day_apy.slice(startIdx);
                aprChart.data.datasets[3].data = aprData.thirty_day_apy.slice(startIdx);
                aprChart.update();
            });
        });

        // APR Legend toggle
        document.querySelectorAll('.apr-legend-item').forEach(item => {
            item.addEventListener('click', function() {
                const series = this.dataset.series;
                seriesVisible[series] = !seriesVisible[series];
                this.classList.toggle('disabled');

                const idx = ['expected', 'implied', 'ninety', 'thirty'].indexOf(series);
                aprChart.data.datasets[idx].hidden = !seriesVisible[series];
                aprChart.update();
            });
        });

        // Populate APR data table
        function populateAPRTable() {
            const tbody = document.getElementById('apr-table-body');
            const rowCountEl = document.getElementById('rowCount');
            let html = '';

            // Show data in reverse chronological order (newest first)
            for (let i = aprData.labels.length - 1; i >= 0; i--) {
                const expected = aprData.expected_apr[i];
                const implied = aprData.implied_apr[i];
                const ninety = aprData.ninety_day_apy[i];
                const thirty = aprData.thirty_day_apy[i];

                html += `<tr>
                    <td>${aprData.labels[i]}</td>
                    <td class="${expected !== null ? (expected >= 0 ? 'positive' : 'negative') : ''}">${expected !== null ? expected.toFixed(2) + '%' : 'N/A'}</td>
                    <td class="${implied !== null ? (implied >= 0 ? 'positive' : 'negative') : ''}">${implied !== null ? implied.toFixed(2) + '%' : 'N/A'}</td>
                    <td class="${ninety !== null ? (ninety >= 0 ? 'positive' : 'negative') : ''}">${ninety !== null ? ninety.toFixed(2) + '%' : 'N/A'}</td>
                    <td class="${thirty !== null ? (thirty >= 0 ? 'positive' : 'negative') : ''}">${thirty !== null ? thirty.toFixed(2) + '%' : 'N/A'}</td>
                </tr>`;
            }

            tbody.innerHTML = html;
            rowCountEl.textContent = `${aprData.labels.length} records`;
        }
        populateAPRTable();

        // ==================== GROWTH METRICS DATA (from growth-metrics.html) ====================
        const growthData = {
            labels: ["2024-06", "2024-07", "2024-08", "2024-09", "2024-10", "2024-11", "2024-12", "2025-01", "2025-02", "2025-03", "2025-04", "2025-05", "2025-06", "2025-07", "2025-08", "2025-09", "2025-10", "2025-11", "2025-12"],
            cumulative_growth: [0.999007, 0.982133, 1.0933, 1.174875, 1.198111, 1.220806, 1.221803, 1.268591, 1.283895, 1.30408, 1.37371, 1.390082, 1.395706, 1.376003, 1.381903, 1.419477, 1.42584, 1.427301, 1.439477],
            incremental_growth: [0, -0.016874, 0.111167, 0.081575, 0.023236, 0.022695, 0.000997, 0.046788, 0.015304, 0.020184, 0.06963, 0.016372, 0.005624, -0.019703, 0.005899, 0.037574, 0.006362, 0.001462, 0.012175],
            total_assets: [99.28, 99305.66, 109330.0, 117487.47, 119811.11, 124957.39, 125059.43, 309502.63, 576119.58, 942283.5, 1279476.36, 1374730.23, 1815609.06, 4489388.19, 5976908.92, 6007878.37, 6001272.02, 7370783.91, 7400766.81],
            usdi_circulation: [100000.0, 100000.0, 100000.0, 100000.0, 100000.0, 122827.76, 122827.76, 309827.74, 569850.31, 927567.96, 1218193.28, 1342717.94, 1783600.05, 4473390.32, 5930185.76, 5947721.95, 5934869.4, 7329655.61, 7297223.15],
            summary: {
                total_growth_pct: 43.95,
                growth_2024_pct: 22.18,
                growth_2025_pct: 21.77,
                current_multiplier: 1.4395,
                current_assets: 7400766.81
            }
        };

        // Format month labels for display
        function formatMonthLabel(label) {
            const [year, month] = label.split('-');
            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            return `${months[parseInt(month) - 1]} ${year}`;
        }

        const growthDisplayLabels = growthData.labels.map(formatMonthLabel);

        // Dollar Value Growth Chart (Cumulative Growth Line)
        const dollarGrowthCtx = document.getElementById('dollarGrowthChart').getContext('2d');
        new Chart(dollarGrowthCtx, {
            type: 'line',
            data: {
                labels: growthDisplayLabels,
                datasets: [{
                    label: 'Cumulative Growth',
                    data: growthData.cumulative_growth,
                    borderColor: colors.accentBlue,
                    backgroundColor: 'rgba(91, 164, 230, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointBackgroundColor: colors.accentBlue,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(26, 43, 95, 0.95)',
                        titleFont: { family: "'Source Serif 4', Georgia, serif" },
                        bodyFont: { family: "'Source Serif 4', Georgia, serif" },
                        callbacks: {
                            label: ctx => `Growth: ${ctx.raw.toFixed(4)}x (${((ctx.raw - 1) * 100).toFixed(2)}%)`
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { color: colors.grid },
                        ticks: { color: colors.text, font: { size: 10, family: "'Source Serif 4', Georgia, serif" }, maxTicksLimit: 10 }
                    },
                    y: {
                        grid: { color: colors.grid },
                        ticks: {
                            color: colors.text,
                            font: { size: 10, family: "'Source Serif 4', Georgia, serif" },
                            callback: v => v.toFixed(2) + 'x'
                        },
                        min: 0.9,
                        max: 1.5
                    }
                }
            }
        });

        // Incremental Growth Bar Chart
        const incrementalGrowthCtx = document.getElementById('incrementalGrowthChart').getContext('2d');
        new Chart(incrementalGrowthCtx, {
            type: 'bar',
            data: {
                labels: growthDisplayLabels,
                datasets: [{
                    label: 'Monthly Change',
                    data: growthData.incremental_growth.map(v => v * 100), // Convert to percentage
                    backgroundColor: growthData.incremental_growth.map(v => v >= 0 ? colors.successGreen : colors.danger),
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(26, 43, 95, 0.95)',
                        titleFont: { family: "'Source Serif 4', Georgia, serif" },
                        bodyFont: { family: "'Source Serif 4', Georgia, serif" },
                        callbacks: {
                            label: ctx => `${ctx.raw >= 0 ? '+' : ''}${ctx.raw.toFixed(2)}%`
                        }
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { color: colors.text, font: { size: 10, family: "'Source Serif 4', Georgia, serif" }, maxTicksLimit: 10 } },
                    y: { grid: { color: colors.grid }, ticks: { color: colors.text, font: { size: 10, family: "'Source Serif 4', Georgia, serif" }, callback: v => v.toFixed(1) + '%' } }
                }
            }
        });

        // Total Assets & USDi Chart
        const assetsUsdiCtx = document.getElementById('assetsUsdiChart').getContext('2d');
        let assetsUsdiChart = new Chart(assetsUsdiCtx, {
            type: 'line',
            data: {
                labels: growthDisplayLabels,
                datasets: [
                    {
                        label: 'Total Assets',
                        data: growthData.total_assets,
                        borderColor: colors.accentBlue,
                        backgroundColor: 'rgba(91, 164, 230, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 4,
                        pointBackgroundColor: colors.accentBlue,
                        borderWidth: 2
                    },
                    {
                        label: 'USDi in Circulation',
                        data: growthData.usdi_circulation,
                        borderColor: colors.successGreen,
                        backgroundColor: 'transparent',
                        fill: false,
                        tension: 0.4,
                        pointRadius: 4,
                        pointBackgroundColor: colors.successGreen,
                        borderWidth: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(26, 43, 95, 0.95)',
                        titleFont: { family: "'Source Serif 4', Georgia, serif" },
                        bodyFont: { family: "'Source Serif 4', Georgia, serif" },
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': $' + context.parsed.y.toLocaleString('en-US', { maximumFractionDigits: 0 });
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { color: colors.grid },
                        ticks: { color: colors.text, font: { size: 10, family: "'Source Serif 4', Georgia, serif" }, maxTicksLimit: 12 }
                    },
                    y: {
                        grid: { color: colors.grid },
                        ticks: {
                            color: colors.text,
                            font: { size: 10, family: "'Source Serif 4', Georgia, serif" },
                            callback: function(value) {
                                if (value >= 1000000) return '$' + (value / 1000000).toFixed(1) + 'M';
                                if (value >= 1000) return '$' + (value / 1000).toFixed(0) + 'K';
                                return '$' + value;
                            }
                        }
                    }
                }
            }
        });

        // Assets/USDi Legend toggle
        document.querySelectorAll('#growth-metrics .legend-item').forEach(item => {
            item.addEventListener('click', function() {
                this.classList.toggle('disabled');
                const series = this.dataset.series;
                const idx = series === 'assets' ? 0 : 1;
                assetsUsdiChart.data.datasets[idx].hidden = !assetsUsdiChart.data.datasets[idx].hidden;
                assetsUsdiChart.update();
            });
        });

        // Growth Breakdown Table
        function populateGrowthBreakdownTable() {
            const tbody = document.getElementById('growth-breakdown-body');
            tbody.innerHTML = '';

            for (let i = growthData.labels.length - 1; i >= 0; i--) {
                const cumulative = growthData.cumulative_growth[i];
                const incremental = growthData.incremental_growth[i];
                const incrementalPct = incremental * 100;

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${formatMonthLabel(growthData.labels[i])}</td>
                    <td class="positive">${cumulative.toFixed(4)}x</td>
                    <td class="${incremental >= 0 ? 'positive' : 'negative'}">${incremental >= 0 ? '+' : ''}${incremental.toFixed(6)}</td>
                    <td class="${incrementalPct >= 0 ? 'positive' : 'negative'}">${incrementalPct >= 0 ? '+' : ''}${incrementalPct.toFixed(2)}%</td>
                `;
                tbody.appendChild(row);
            }
        }

        // Assets & USDi Monthly Breakdown Table
        function populateAssetsUsdiTable() {
            const tbody = document.getElementById('assets-usdi-body');
            tbody.innerHTML = '';

            const formatter = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 });

            for (let i = growthData.labels.length - 1; i >= 0; i--) {
                const assets = growthData.total_assets[i];
                const usdi = growthData.usdi_circulation[i];
                const diff = assets - usdi;

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${formatMonthLabel(growthData.labels[i])}</td>
                    <td>${formatter.format(assets)}</td>
                    <td>${formatter.format(usdi)}</td>
                    <td class="${diff >= 0 ? 'positive' : 'negative'}">${formatter.format(diff)}</td>
                `;
                tbody.appendChild(row);
            }
        }

        populateGrowthBreakdownTable();
        populateAssetsUsdiTable();

        // ==================== ASSET POOL DATA (from asset-pool.html) ====================
        // Current Asset Pool - Dark blue theme colors
        const currentAssets = [
            { symbol: 'SOL', apr: '2.08% APR', value: '$4.6M', percent: '62.4%', color: '#0f1a3d' },
            { symbol: 'BTC', apr: '2.01% APR', value: '$1.4M', percent: '18.9%', color: '#1a2b5f' },
            { symbol: 'DOGE', apr: '0.10% APR', value: '$779K', percent: '10.5%', color: '#2c4a8c' },
            { symbol: 'UNI', apr: '8.08% APR', value: '$560K', percent: '7.6%', color: '#3d5a9c' },
            { symbol: 'USDC', apr: 'Stablecoin', value: '$44K', percent: '0.6%', color: '#4e6aac' },
            { symbol: 'USDT', apr: 'Stablecoin', value: '$977', percent: '0.01%', color: '#5f7abc' }
        ];

        // Simulated Asset Pool - More transparent/lighter colors
        const simulatedAssets = [
            { symbol: 'EOS', apr: '48.36% APR', percent: '50%', color: 'rgba(91, 164, 230, 0.7)' },
            { symbol: 'MATIC', apr: '16.73% APR', percent: '15%', color: 'rgba(91, 164, 230, 0.55)' },
            { symbol: 'FTM', apr: '10.98% APR', percent: '15%', color: 'rgba(91, 164, 230, 0.4)' },
            { symbol: 'RUNE', apr: '9.84% APR', percent: '10%', color: 'rgba(91, 164, 230, 0.3)' },
            { symbol: 'CHZ', apr: '9.61% APR', percent: '10%', color: 'rgba(91, 164, 230, 0.2)' }
        ];

        // Total Pool Assets (39 assets)
        const totalPoolAssets = ['BTC', 'ETH', 'SOL', 'BNB', 'XRP', 'ADA', 'DOGE', 'AVAX', 'DOT', 'LINK', 'LTC', 'BCH', 'NEAR', 'UNI', 'SUI', 'APT', 'ATOM', 'OP', 'FIL', 'XLM', 'TRX', 'AAVE', 'ETC', 'ALGO', 'FTM', 'THETA', 'EOS', 'EGLD', 'SAND', 'MANA', 'AXS', 'ENS', 'GMT', 'CHZ', 'RUNE', 'WLD', 'WIF', 'MATIC', 'DOGS'];

        // Full Asset Monitor data from source
        const assetMonitor = [
            { rank: 1, symbol: 'EOS', marketCap: '$109M', volume: '$13K', fdv: '$369M', allocation: 50, aprScore: 48.36, expectedAPY: 48.36, day3: 52.27, day7: 28.57, day30: 12.29 },
            { rank: 2, symbol: 'MATIC', marketCap: '$1.3B', volume: '$38M', fdv: '$1.3B', allocation: 15, aprScore: 16.73, expectedAPY: 16.73, day3: 15.81, day7: 12.81, day30: 6.08 },
            { rank: 3, symbol: 'FTM', marketCap: '$344M', volume: '$28M', fdv: '$353M', allocation: 15, aprScore: 10.98, expectedAPY: 10.98, day3: 10.80, day7: 10.96, day30: 12.31 },
            { rank: 4, symbol: 'RUNE', marketCap: '$228M', volume: '$202M', fdv: '$275M', allocation: 10, aprScore: 9.84, expectedAPY: 9.84, day3: 10.80, day7: 8.15, day30: 6.46 },
            { rank: 5, symbol: 'CHZ', marketCap: '$339M', volume: '$47M', fdv: '$339M', allocation: 10, aprScore: 9.61, expectedAPY: 9.61, day3: 11.23, day7: 6.95, day30: 5.37 },
            { rank: 6, symbol: 'ETC', marketCap: '$2.0B', volume: '$31M', fdv: '$2.0B', allocation: 0, aprScore: 9.35, expectedAPY: 9.35, day3: 7.70, day7: 8.71, day30: 9.72 },
            { rank: 7, symbol: 'WLD', marketCap: '$1.5B', volume: '$60M', fdv: '$5.9B', allocation: 0, aprScore: 8.80, expectedAPY: 8.80, day3: 10.52, day7: 4.50, day30: 4.19 },
            { rank: 8, symbol: 'ALGO', marketCap: '$1.1B', volume: '$29M', fdv: '$1.1B', allocation: 0, aprScore: 8.32, expectedAPY: 8.32, day3: 6.28, day7: 7.06, day30: 7.09 },
            { rank: 9, symbol: 'UNI', marketCap: '$3.4B', volume: '$148M', fdv: '$5.5B', allocation: 0, aprScore: 8.08, expectedAPY: 8.08, day3: 7.35, day7: 5.46, day30: 4.67 },
            { rank: 10, symbol: 'LINK', marketCap: '$9.5B', volume: '$327M', fdv: '$13.7B', allocation: 0, aprScore: 7.87, expectedAPY: 7.87, day3: 7.46, day7: 3.99, day30: 5.13 },
            { rank: 11, symbol: 'SUI', marketCap: '$6.0B', volume: '$398M', fdv: '$16.0B', allocation: 0, aprScore: 6.51, expectedAPY: 6.51, day3: 4.88, day7: 4.63, day30: 5.29 },
            { rank: 12, symbol: 'WIF', marketCap: '$396M', volume: '$107M', fdv: '$396M', allocation: 0, aprScore: 6.46, expectedAPY: 6.46, day3: 4.02, day7: 6.07, day30: 1.42 },
            { rank: 13, symbol: 'FIL', marketCap: '$976M', volume: '$71M', fdv: '$2.6B', allocation: 0, aprScore: 6.09, expectedAPY: 6.09, day3: -0.26, day7: 5.55, day30: 8.43 },
            { rank: 14, symbol: 'ENS', marketCap: '$415M', volume: '$12M', fdv: '$1.1B', allocation: 0, aprScore: 6.04, expectedAPY: 6.04, day3: 10.61, day7: 1.96, day30: -3.41 },
            { rank: 15, symbol: 'LTC', marketCap: '$6.2B', volume: '$294M', fdv: '$6.2B', allocation: 0, aprScore: 5.95, expectedAPY: 5.95, day3: 3.50, day7: 3.03, day30: 6.14 },
            { rank: 16, symbol: 'XLM', marketCap: '$7.7B', volume: '$66M', fdv: '$11.9B', allocation: 0, aprScore: 4.97, expectedAPY: 4.97, day3: 3.15, day7: 1.37, day30: 0.79 },
            { rank: 17, symbol: 'ADA', marketCap: '$15.0B', volume: '$365M', fdv: '$18.4B', allocation: 0, aprScore: 4.93, expectedAPY: 4.93, day3: 1.52, day7: 2.76, day30: 3.77 },
            { rank: 18, symbol: 'NEAR', marketCap: '$2.1B', volume: '$106M', fdv: '$2.1B', allocation: 0, aprScore: 3.60, expectedAPY: 3.60, day3: 4.03, day7: 7.38, day30: 4.73 },
            { rank: 19, symbol: 'MANA', marketCap: '$278M', volume: '$16M', fdv: '$318M', allocation: 0, aprScore: 2.26, expectedAPY: 2.26, day3: -2.82, day7: -5.91, day30: -0.27 },
            { rank: 20, symbol: 'SOL', marketCap: '$74.5B', volume: '$2.3B', fdv: '$81.7B', allocation: 0, aprScore: 2.08, expectedAPY: 2.08, day3: -1.83, day7: -0.59, day30: 0.74 },
            { rank: 21, symbol: 'BTC', marketCap: '$1.8T', volume: '$35.3B', fdv: '$1.8T', allocation: 0, aprScore: 2.01, expectedAPY: 2.01, day3: 0.74, day7: -0.08, day30: 1.91 },
            { rank: 22, symbol: 'XRP', marketCap: '$121.8B', volume: '$1.7B', fdv: '$201.9B', allocation: 0, aprScore: 1.84, expectedAPY: 1.84, day3: -0.28, day7: 0.13, day30: 1.75 },
            { rank: 23, symbol: 'AAVE', marketCap: '$3.0B', volume: '$238M', fdv: '$3.2B', allocation: 0, aprScore: 1.55, expectedAPY: 1.55, day3: 3.03, day7: 1.42, day30: 7.75 },
            { rank: 24, symbol: 'TRX', marketCap: '$25.7B', volume: '$406M', fdv: '$25.7B', allocation: 0, aprScore: 1.13, expectedAPY: 1.13, day3: 4.21, day7: -1.19, day30: 1.86 },
            { rank: 25, symbol: 'THETA', marketCap: '$355M', volume: '$13M', fdv: '$355M', allocation: 0, aprScore: 0.95, expectedAPY: 0.95, day3: 1.21, day7: 2.49, day30: -6.93 },
            { rank: 26, symbol: 'AXS', marketCap: '$168M', volume: '$11M', fdv: '$271M', allocation: 0, aprScore: 0.74, expectedAPY: 0.74, day3: -6.37, day7: 3.20, day30: -23.04 },
            { rank: 27, symbol: 'SAND', marketCap: '$346M', volume: '$16M', fdv: '$398M', allocation: 0, aprScore: 0.35, expectedAPY: 0.35, day3: 8.45, day7: 6.15, day30: 6.99 },
            { rank: 28, symbol: 'BNB', marketCap: '$123.2B', volume: '$906M', fdv: '$123.2B', allocation: 0, aprScore: 0.27, expectedAPY: 0.27, day3: 0.00, day7: 0.00, day30: 2.72 },
            { rank: 29, symbol: 'DOGE', marketCap: '$23.3B', volume: '$550M', fdv: '$23.3B', allocation: 0, aprScore: 0.10, expectedAPY: 0.10, day3: 1.89, day7: 3.77, day30: 1.60 },
            { rank: 30, symbol: 'ETH', marketCap: '$375.2B', volume: '$10.0B', fdv: '$375.2B', allocation: 0, aprScore: -0.16, expectedAPY: -0.16, day3: -0.87, day7: 1.95, day30: 3.99 },
            { rank: 31, symbol: 'GMT', marketCap: '$51M', volume: '$12M', fdv: '$82M', allocation: 0, aprScore: -2.36, expectedAPY: -2.36, day3: 6.64, day7: -8.67, day30: -13.23 },
            { rank: 32, symbol: 'AVAX', marketCap: '$5.7B', volume: '$229M', fdv: '$6.1B', allocation: 0, aprScore: -2.83, expectedAPY: -2.83, day3: -9.38, day7: -1.92, day30: -7.60 },
            { rank: 33, symbol: 'OP', marketCap: '$613M', volume: '$47M', fdv: '$1.4B', allocation: 0, aprScore: -5.45, expectedAPY: -5.45, day3: 5.86, day7: -2.03, day30: -5.13 },
            { rank: 34, symbol: 'ATOM', marketCap: '$1.0B', volume: '$25M', fdv: '$1.0B', allocation: 0, aprScore: -6.02, expectedAPY: -6.02, day3: -11.80, day7: -12.50, day30: -14.99 },
            { rank: 35, symbol: 'DOT', marketCap: '$3.3B', volume: '$104M', fdv: '$3.3B', allocation: 0, aprScore: -6.17, expectedAPY: -6.17, day3: -6.26, day7: -3.05, day30: -4.57 },
            { rank: 36, symbol: 'BCH', marketCap: '$11.5B', volume: '$188M', fdv: '$11.5B', allocation: 0, aprScore: -12.94, expectedAPY: -12.94, day3: -9.72, day7: -10.53, day30: -1.50 },
            { rank: 37, symbol: 'APT', marketCap: '$1.3B', volume: '$177M', fdv: '$2.0B', allocation: 0, aprScore: -13.26, expectedAPY: -13.26, day3: 0.19, day7: -3.25, day30: -14.72 },
            { rank: 38, symbol: 'EGLD', marketCap: '$215M', volume: '$9M', fdv: '$215M', allocation: 0, aprScore: -14.36, expectedAPY: -14.36, day3: -14.38, day7: -41.10, day30: -31.38 },
            { rank: 39, symbol: 'DOGS', marketCap: '$26M', volume: '$7M', fdv: '$27M', allocation: 0, aprScore: -102.60, expectedAPY: -102.60, day3: -111.88, day7: -143.52, day30: -46.54 }
        ];

        // Populate Current Asset List
        function populateCurrentAssets() {
            const container = document.getElementById('current-asset-list');
            container.innerHTML = currentAssets.map(asset => `
                <div class="asset-item">
                    <div class="asset-item-left">
                        <div class="asset-icon" style="background: ${asset.color};">${asset.symbol.charAt(0)}</div>
                        <div class="asset-info">
                            <span class="asset-symbol">${asset.symbol}</span>
                            <span class="asset-apr">${asset.apr}</span>
                        </div>
                    </div>
                    <div class="asset-item-right">
                        <span class="asset-value">${asset.value}</span>
                        <span class="asset-percent">${asset.percent}</span>
                    </div>
                </div>
            `).join('');
        }

        // Populate Simulated Asset List
        function populateSimulatedAssets() {
            const container = document.getElementById('simulated-asset-list');
            container.innerHTML = simulatedAssets.map(asset => `
                <div class="asset-item">
                    <div class="asset-item-left">
                        <div class="asset-icon" style="background: ${asset.color};">${asset.symbol.charAt(0)}</div>
                        <div class="asset-info">
                            <span class="asset-symbol">${asset.symbol}</span>
                            <span class="asset-apr">${asset.apr}</span>
                        </div>
                    </div>
                    <div class="asset-item-right">
                        <span class="asset-value">${asset.percent}</span>
                    </div>
                </div>
            `).join('');
        }

        // Populate Asset Tags
        function populateAssetTags() {
            const container = document.getElementById('asset-tags');
            container.innerHTML = totalPoolAssets.map(symbol => `
                <span class="asset-tag">${symbol}</span>
            `).join('');
        }

        // Asset Monitor Table
        function populateAssetMonitorTable() {
            const tbody = document.getElementById('asset-monitor-body');
            tbody.innerHTML = '';

            assetMonitor.forEach(asset => {
                const row = document.createElement('tr');
                const aprClass = asset.aprScore >= 0 ? 'positive' : 'negative';
                const day3Class = asset.day3 >= 0 ? 'positive' : 'negative';
                const day7Class = asset.day7 >= 0 ? 'positive' : 'negative';
                const day30Class = asset.day30 >= 0 ? 'positive' : 'negative';

                row.innerHTML = `
                    <td>${asset.rank}</td>
                    <td><strong>${asset.symbol}</strong></td>
                    <td>${asset.marketCap}</td>
                    <td>${asset.volume}</td>
                    <td>${asset.fdv}</td>
                    <td>${asset.allocation > 0 ? asset.allocation + '%' : '0%'}</td>
                    <td class="${aprClass}">${asset.aprScore.toFixed(2)}%</td>
                    <td class="${aprClass}">${asset.expectedAPY.toFixed(2)}%</td>
                    <td class="${day3Class}">${asset.day3.toFixed(2)}%</td>
                    <td class="${day7Class}">${asset.day7.toFixed(2)}%</td>
                    <td class="${day30Class}">${asset.day30.toFixed(2)}%</td>
                `;
                tbody.appendChild(row);
            });
        }

        populateCurrentAssets();
        populateSimulatedAssets();
        populateAssetTags();
        populateAssetMonitorTable();

        // ==================== ASSET POOL PIE CHARTS ====================
        // Current Pool Pie Chart - Blue theme (dark to light navy)
        const currentPoolColors = ['#0f1a3d', '#1a2b5f', '#2c4a8c', '#3d5a9c', '#4e6aac', '#5f7abc'];
        const currentPoolData = {
            labels: ['SOL', 'BTC', 'DOGE', 'UNI', 'USDC', 'USDT'],
            percentages: [62.4, 18.9, 10.5, 7.6, 0.34, 0.22]
        };

        const currentPoolCtx = document.getElementById('currentPoolChart').getContext('2d');
        new Chart(currentPoolCtx, {
            type: 'doughnut',
            data: {
                labels: currentPoolData.labels,
                datasets: [{
                    data: currentPoolData.percentages,
                    backgroundColor: currentPoolColors,
                    borderWidth: 0,
                    cutout: '55%'
                }]
            },
            plugins: [ChartDataLabels],
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    datalabels: {
                        display: true,
                        color: '#FFFFFF',
                        font: { family: "'Source Serif 4', serif", weight: 'bold', size: 10 },
                        formatter: (value) => value > 5 ? value.toFixed(1) + '%' : '',
                        anchor: 'center',
                        align: 'center'
                    },
                    tooltip: {
                        backgroundColor: 'rgba(26, 43, 95, 0.95)',
                        titleFont: { family: "'Source Serif 4', Georgia, serif" },
                        bodyFont: { family: "'Source Serif 4', Georgia, serif" },
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed.toFixed(2) + '%';
                            }
                        }
                    }
                }
            }
        });

        // Simulated Pool Pie Chart - Transparent blue theme
        const simulatedPoolColors = [
            'rgba(91, 164, 230, 0.9)',
            'rgba(91, 164, 230, 0.7)',
            'rgba(91, 164, 230, 0.55)',
            'rgba(91, 164, 230, 0.4)',
            'rgba(91, 164, 230, 0.25)'
        ];
        const simulatedPoolData = {
            labels: ['EOS', 'MATIC', 'FTM', 'RUNE', 'CHZ'],
            percentages: [50, 15, 15, 10, 10]
        };

        const simulatedPoolCtx = document.getElementById('simulatedPoolChart').getContext('2d');
        new Chart(simulatedPoolCtx, {
            type: 'doughnut',
            data: {
                labels: simulatedPoolData.labels,
                datasets: [{
                    data: simulatedPoolData.percentages,
                    backgroundColor: simulatedPoolColors,
                    borderWidth: 2,
                    borderColor: 'rgba(91, 164, 230, 0.3)',
                    cutout: '55%'
                }]
            },
            plugins: [ChartDataLabels],
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    datalabels: {
                        display: true,
                        color: '#1a2b5f',
                        font: { family: "'Source Serif 4', serif", weight: 'bold', size: 10 },
                        formatter: (value) => value + '%',
                        anchor: 'center',
                        align: 'center'
                    },
                    tooltip: {
                        backgroundColor: 'rgba(26, 43, 95, 0.95)',
                        titleFont: { family: "'Source Serif 4', Georgia, serif" },
                        bodyFont: { family: "'Source Serif 4', Georgia, serif" },
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + '%';
                            }
                        }
                    }
                }
            }
        });

        // ==================== REVENUE & COMMISSION DATA (from revenue-commission-metrics.html) ====================
        const revenueData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'],
            fullLabels: ['January 2025', 'February 2025', 'March 2025', 'April 2025', 'May 2025', 'June 2025', 'July 2025', 'August 2025', 'September 2025', 'October 2025', 'November 2025'],
            commission: {
                monthly: [6147.01, 0, 2015.29, 15241.10, 12127.40, 3260.29, 5578.38, 9886.13, 6215.68, 5140.57, 0],
                cumulative: [6147.01, 6147.01, 8162.30, 23403.40, 35530.80, 38791.09, 44369.47, 54255.60, 60471.28, 65611.85, 65611.85]
            },
            revenue: {
                monthly: [0, 0, 19485.54, 25888.29, 113196.62, 16290.03, 29486.23, 49417.33, 31078.27, 25612.82, 0],
                cumulative: [0, 0, 19485.54, 45373.83, 158570.45, 174860.48, 204346.71, 253764.04, 284842.31, 310455.13, 310455.13]
            }
        };

        // Series visibility for revenue chart
        const revenueSeriesVisible = {
            revenue: true,
            commission: true
        };

        let currentRevenueView = 'monthly';

        // Revenue Chart
        let revenueChart;
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');

        function createRevenueChart(viewType) {
            if (revenueChart) revenueChart.destroy();
            currentRevenueView = viewType;

            const isMonthly = viewType === 'monthly';

            revenueChart = new Chart(revenueCtx, {
                type: 'bar',
                data: {
                    labels: revenueData.labels,
                    datasets: [
                        {
                            label: 'Revenue',
                            data: isMonthly ? revenueData.revenue.monthly : revenueData.revenue.cumulative,
                            backgroundColor: colors.successGreen,
                            borderRadius: 4,
                            order: 1,
                            hidden: !revenueSeriesVisible.revenue
                        },
                        {
                            label: 'Commission',
                            data: isMonthly ? revenueData.commission.monthly : revenueData.commission.cumulative,
                            backgroundColor: colors.accentBlue,
                            borderRadius: 4,
                            order: 2,
                            hidden: !revenueSeriesVisible.commission
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(26, 43, 95, 0.95)',
                            titleFont: { family: "'Source Serif 4', Georgia, serif" },
                            bodyFont: { family: "'Source Serif 4', Georgia, serif" },
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': $' + context.parsed.y.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: {
                                color: colors.text,
                                font: { size: 11, family: "'Source Serif 4', Georgia, serif" }
                            }
                        },
                        y: {
                            grid: { color: colors.grid },
                            ticks: {
                                color: colors.text,
                                font: { size: 10, family: "'Source Serif 4', Georgia, serif" },
                                callback: function(value) {
                                    if (value >= 1000000) return '$' + (value / 1000000).toFixed(1) + 'M';
                                    if (value >= 1000) return '$' + (value / 1000).toFixed(0) + 'K';
                                    return '$' + value;
                                }
                            }
                        }
                    }
                }
            });
        }

        createRevenueChart('monthly');

        // View toggle
        document.querySelectorAll('#revenue-commission .view-toggle-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('#revenue-commission .view-toggle-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                createRevenueChart(this.dataset.view);
            });
        });

        // Revenue Legend toggle
        document.querySelectorAll('#revenue-commission .legend-item').forEach(item => {
            item.addEventListener('click', function() {
                this.classList.toggle('disabled');
                const series = this.dataset.series;
                revenueSeriesVisible[series] = !revenueSeriesVisible[series];
                const idx = series === 'revenue' ? 0 : 1;
                revenueChart.data.datasets[idx].hidden = !revenueSeriesVisible[series];
                revenueChart.update();
            });
        });

        // Revenue Table - columns: Month, Commission, Cumulative Commission, Revenue, Cumulative Revenue
        function populateRevenueTable() {
            const tbody = document.getElementById('revenue-table-body');
            tbody.innerHTML = '';

            const formatter = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 });

            for (let i = revenueData.fullLabels.length - 1; i >= 0; i--) {
                const commission = revenueData.commission.monthly[i];
                const cumCommission = revenueData.commission.cumulative[i];
                const revenue = revenueData.revenue.monthly[i];
                const cumRevenue = revenueData.revenue.cumulative[i];

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${revenueData.fullLabels[i]}</td>
                    <td>${formatter.format(commission)}</td>
                    <td>${formatter.format(cumCommission)}</td>
                    <td>${revenue > 0 ? formatter.format(revenue) : '-'}</td>
                    <td>${cumRevenue > 0 ? formatter.format(cumRevenue) : '-'}</td>
                `;
                tbody.appendChild(row);
            }
        }

        populateRevenueTable();

        // ==================== UTILITY FUNCTIONS ====================
        function refreshData() {
            // Simulate data refresh
            const btn = event.target.closest('.btn');
            btn.innerHTML = '<svg class="spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg> Refreshing...';

            setTimeout(() => {
                btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg> Refresh Data';
            }, 1500);
        }

        // Add spin animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            .spin {
                animation: spin 1s linear infinite;
            }
        `;
        document.head.appendChild(style);