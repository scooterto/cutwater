import React, { useState, useEffect } from "react";
import "./SignInPage.css";

/**
 * Cutwater Sign In / Sign Up Page Component
 *
 * Features:
 * - Email authentication with one-time passcode
 * - Google OAuth integration
 * - Apple sign-in integration
 * - Dark/light mode toggle with localStorage persistence
 * - Responsive design (mobile-friendly)
 * - Cutwater branding from v4 design system
 *
 * Dependencies:
 * - React 18+
 * - Google Fonts: Playfair Display, Source Serif 4, Noto Sans
 */

const SignInPage = () => {
  const [email, setEmail] = useState("");
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Initialize theme from localStorage on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem("cutwater-theme") || "light";
    if (savedTheme === "dark") {
      setIsDarkMode(true);
      document.body.classList.add("dark-mode");
    }
  }, []);

  // Toggle theme and persist to localStorage
  const toggleTheme = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);

    if (newMode) {
      document.body.classList.add("dark-mode");
      localStorage.setItem("cutwater-theme", "dark");
    } else {
      document.body.classList.remove("dark-mode");
      localStorage.setItem("cutwater-theme", "light");
    }
  };

  // Handle email authentication submission
  const handleEmailSubmit = (e) => {
    e.preventDefault();
    console.log("Email submitted:", email);
    // TODO: Implement email authentication logic
    // - Send OTP to email
    // - Navigate to OTP verification page
  };

  // Handle Google OAuth sign-in
  const handleGoogleSignIn = () => {
    console.log("Google sign in");
    // TODO: Implement Google OAuth logic
    // - Initialize Google OAuth flow
    // - Handle callback and token exchange
  };

  // Handle Apple sign-in
  const handleAppleSignIn = () => {
    console.log("Apple sign in");
    // TODO: Implement Apple sign-in logic
    // - Initialize Apple sign-in flow
    // - Handle callback and token exchange
  };

  // Handle sign-up navigation
  const handleSignUp = () => {
    console.log("Navigate to sign up");
    // TODO: Navigate to sign-up page or modal
  };

  return (
    <div className="signin-container">
      {/* Left Side - Branding Panel */}
      <div className="brand-side">
        <div className="brand-gradient"></div>
        <div className="brand-content">
          {/* Logo Section */}
          <div className="logo-section">
            <svg
              className="logo-icon"
              viewBox="0 0 48 48"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M34 10C28 6 18 6 12 12C6 18 6 30 12 36C18 42 28 42 34 38"
                stroke="#ffffff"
                strokeWidth="4"
                strokeLinecap="round"
              />
              <g className="balance-line">
                <path
                  d="M14 24L34 24"
                  stroke="#5BA4E6"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
              </g>
              <circle cx="24" cy="24" r="4" fill="#5BA4E6" />
            </svg>
            <span className="logo-text">Cutwater</span>
          </div>

          {/* Tagline */}
          <div>
            <h1 className="brand-headline">
              Earn passive income automatically with USDi stablecoin.
            </h1>
          </div>
        </div>
      </div>

      {/* Right Side - Sign In Form */}
      <div className="form-side">
        {/* Theme Toggle Button */}
        <button
          className="theme-toggle"
          onClick={toggleTheme}
          aria-label="Toggle theme"
        >
          <svg
            className="sun-icon"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <circle cx="12" cy="12" r="5" />
            <line x1="12" y1="1" x2="12" y2="3" />
            <line x1="12" y1="21" x2="12" y2="23" />
            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
            <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
            <line x1="1" y1="12" x2="3" y2="12" />
            <line x1="21" y1="12" x2="23" y2="12" />
            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
            <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
          </svg>
          <svg
            className="moon-icon"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
          </svg>
        </button>

        {/* Form Container */}
        <div className="form-container">
          {/* Form Header */}
          <div className="form-header">
            <h2 className="form-title">Welcome to Cutwater</h2>
            <p className="form-subtitle">
              Sign in to start earning multi-asset yields
            </p>
          </div>

          {/* Email Form */}
          <form onSubmit={handleEmailSubmit}>
            <div className="form-group">
              <label className="form-label" htmlFor="email">
                Email Address
              </label>
              <div className="input-wrapper">
                <svg
                  className="input-icon"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
                <input
                  id="email"
                  type="email"
                  className="form-input"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <p className="form-help">
                We'll send you a one-time passcode to sign in
              </p>
            </div>

            <button type="submit" className="btn btn-primary">
              Continue with Email
            </button>
          </form>

          {/* Divider */}
          <div className="divider">
            <div className="divider-line"></div>
            <span className="divider-text">or</span>
            <div className="divider-line"></div>
          </div>

          {/* Social Sign-In Buttons */}
          <button className="btn btn-social" onClick={handleGoogleSignIn}>
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                fill="#4285F4"
              />
              <path
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                fill="#34A853"
              />
              <path
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                fill="#FBBC05"
              />
              <path
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                fill="#EA4335"
              />
            </svg>
            Continue with Google
          </button>

          <button className="btn btn-social" onClick={handleAppleSignIn}>
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
            </svg>
            Continue with Apple
          </button>

          {/* Sign Up Footer */}
          <div className="form-footer">
            <p className="form-footer-text">
              Don't have an account?{" "}
              <span className="form-footer-link" onClick={handleSignUp}>
                Sign up
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignInPage;
