# Cutwater Sign In Page Component

A production-ready React component for the Cutwater sign-in/sign-up page with Cutwater v4 branding.

## Features

- ✅ Email authentication with one-time passcode flow
- ✅ Google OAuth integration (ready for implementation)
- ✅ Apple Sign-In integration (ready for implementation)
- ✅ Dark/Light mode toggle with localStorage persistence
- ✅ Fully responsive design (desktop, tablet, mobile)
- ✅ Cutwater v4 brand design system
- ✅ Animated logo with accessibility support
- ✅ Clean, modular code structure

## Files

- `SignInPage.jsx` - Main React component
- `SignInPage.css` - Component styles with CSS variables
- `package.json` - Dependencies and package info
- `README-SignIn.md` - This file

## Requirements

- React 18+
- Modern browser with CSS Grid support
- Internet connection for Google Fonts

## Installation

### Option 1: Copy files to your React project

1. Copy `SignInPage.jsx` and `SignInPage.css` to your components directory:

   ```
   src/
   └── components/
       └── SignInPage/
           ├── SignInPage.jsx
           └── SignInPage.css
   ```

2. Import and use in your app:

   ```jsx
   import SignInPage from "./components/SignInPage/SignInPage";

   function App() {
     return <SignInPage />;
   }
   ```

### Option 2: Use as a page in React Router

```jsx
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SignInPage from "./components/SignInPage/SignInPage";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/signin" element={<SignInPage />} />
        {/* other routes */}
      </Routes>
    </BrowserRouter>
  );
}
```

## Implementation Guide

### 1. Email Authentication

Replace the placeholder in `handleEmailSubmit`:

```jsx
const handleEmailSubmit = async (e) => {
  e.preventDefault();

  try {
    // Call your API to send OTP
    const response = await fetch("/api/auth/send-otp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    if (response.ok) {
      // Navigate to OTP verification page
      navigate("/verify-otp", { state: { email } });
    }
  } catch (error) {
    console.error("Email auth failed:", error);
  }
};
```

### 2. Google OAuth

Replace the placeholder in `handleGoogleSignIn`:

```jsx
const handleGoogleSignIn = () => {
  // Using Firebase Auth
  import { signInWithPopup, GoogleAuthProvider } from "firebase/auth";

  const provider = new GoogleAuthProvider();
  signInWithPopup(auth, provider)
    .then((result) => {
      // Handle successful sign-in
      const user = result.user;
      navigate("/dashboard");
    })
    .catch((error) => {
      console.error("Google sign-in failed:", error);
    });
};
```

Or use your OAuth library:

```jsx
const handleGoogleSignIn = () => {
  // Redirect to your OAuth endpoint
  window.location.href = "/api/auth/google";
};
```

### 3. Apple Sign-In

Replace the placeholder in `handleAppleSignIn`:

```jsx
const handleAppleSignIn = () => {
  // Using Firebase Auth
  import { signInWithPopup, OAuthProvider } from "firebase/auth";

  const provider = new OAuthProvider("apple.com");
  signInWithPopup(auth, provider)
    .then((result) => {
      const user = result.user;
      navigate("/dashboard");
    })
    .catch((error) => {
      console.error("Apple sign-in failed:", error);
    });
};
```

### 4. Sign Up Navigation

Replace the placeholder in `handleSignUp`:

```jsx
const handleSignUp = () => {
  // Option 1: Navigate to sign-up page
  navigate("/signup");

  // Option 2: Open sign-up modal
  setShowSignUpModal(true);

  // Option 3: Switch to sign-up mode
  setAuthMode("signup");
};
```

## Customization

### Colors

All colors are defined as CSS variables in `SignInPage.css`:

```css
:root {
  --dark-navy: #0f1a3d;
  --primary-navy: #1a2b5f;
  --highlight-blue: #1e88e5;
  /* ... more colors */
}
```

### Typography

Fonts are from Google Fonts (loaded in CSS):

- **Playfair Display** - Headings, large text
- **Source Serif 4** - Body text, labels
- **Noto Sans** - Currency symbols

To change fonts, update the CSS variables:

```css
:root {
  --font-display: "Your Display Font", serif;
  --font-body: "Your Body Font", serif;
}
```

### Tagline

Edit the tagline in `SignInPage.jsx`:

```jsx
<h1 className="brand-headline">Your custom tagline here</h1>
```

### Remove Social Login

To remove Google or Apple sign-in, simply delete the corresponding button:

```jsx
// Remove this entire block
<button className="btn btn-social" onClick={handleGoogleSignIn}>
  {/* ... */}
</button>
```

## Accessibility

The component includes:

- Proper ARIA labels
- Keyboard navigation support
- Focus states on all interactive elements
- Reduced motion support for animations
- Semantic HTML structure

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari 14+, Chrome Android)

## Live Demo

View the live component:
https://scooterto.github.io/cutwater/website/cutwater-signin-page.html

## Design System

This component follows the Cutwater v4 design system:

- View brand guidelines: https://scooterto.github.io/cutwater/website/brand-guidelines-v4.html
- Landing page reference: https://scooterto.github.io/cutwater/landing-page-v4.html

## Notes for Developers

### Theme Persistence

The component uses `localStorage` to persist the user's theme preference across sessions. The theme is stored with the key `cutwater-theme`.

### Body Class Management

The component adds/removes the `dark-mode` class to the `<body>` element. If you have other components that need to respond to theme changes, listen for this class.

### Form Validation

The email input has basic HTML5 validation (`type="email"` and `required`). Add custom validation as needed:

```jsx
const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};
```

### Loading States

Add loading states to buttons during authentication:

```jsx
const [isLoading, setIsLoading] = useState(false);

const handleEmailSubmit = async (e) => {
  e.preventDefault();
  setIsLoading(true);

  try {
    await sendOTP(email);
  } finally {
    setIsLoading(false);
  }
};

// In JSX:
<button disabled={isLoading}>
  {isLoading ? "Sending..." : "Continue with Email"}
</button>;
```

### Error Handling

Add error state and display:

```jsx
const [error, setError] = useState("");

// In JSX:
{
  error && <div className="error-message">{error}</div>;
}
```

## Support

For questions or issues, contact the Cutwater development team.

## License

Proprietary - Cutwater Partners © 2025
